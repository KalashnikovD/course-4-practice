## Node.js version
v18.15.0

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Ready assembly in the "build" folder
Open the index.html please
